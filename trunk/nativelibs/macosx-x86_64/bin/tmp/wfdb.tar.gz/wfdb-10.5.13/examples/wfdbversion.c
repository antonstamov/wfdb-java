#include <stdio.h>
#include <wfdb/wfdb.h>

main()
{
    printf("%s", wfdberror());
}
